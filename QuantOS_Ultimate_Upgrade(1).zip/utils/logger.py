"""
QuantOS Logging Utilities

This module implements a standardized logging system for the QuantOS platform.
"""
import logging
import logging.config
import logging.handlers
from typing import Any, Optional
from pathlib import Path

from ..config.settings import Config


def setup_logger(name: Optional[str] = None, config: Optional[dict] = None) -> logging.Logger:
    """
    Setup and return a logger with QuantOS standard configuration
    
    Args:
        name (str, optional): Logger name. Defaults to package root.
        config (dict, optional): Custom logging config. Defaults to None.
        
    Returns:
        logging.Logger: Configured logger instance
    """
    logging.config.dictConfig(config or Config.LOGGING_CONFIG)
    return logging.getLogger(name)


def get_file_handler(log_path: Path, level: str = 'DEBUG', max_bytes: int = 10**7, backup_count: int = 5) -> logging.Handler:
    """
    Create a file handler with rotation policy
    
    Args:
        log_path: Path to log file
        level: Logging level
        max_bytes: Max file size before rotation
        backup_count: Number of backup files to keep
        
    Returns:
        Configured file handler
    """
    handler = logging.handlers.RotatingFileHandler(
        filename=str(log_path),
        maxBytes=max_bytes,
        backupCount=backup_count
    )
    handler.setLevel(level)
    handler.setFormatter(
        logging.Formatter('%(asctime)s [%(levelname)s] %(name)s: %(message)s')
    )
    return handler


class StructuredLogger:
    """
    Structured logging wrapper that supports context and metrics
    """
    def __init__(self, name: str):
        self.logger = setup_logger(name)
    
    def debug(self, message: str, **kwargs: Any) -> None:
        """Log debug message with structured context"""
        self.logger.debug(message, extra={'structured_data': kwargs})
    
    def info(self, message: str, **kwargs: Any) -> None:
        """Log info message with structured context"""
        self.logger.info(message, extra={'structured_data': kwargs})
    
    def warning(self, message: str, **kwargs: Any) -> None:
        """Log warning message with structured context"""
        self.logger.warning(message, extra={'structured_data': kwargs})
    
    def error(self, message: str, **kwargs: Any) -> None:
        """Log error message with structured context"""
        self.logger.error(message, extra={'structured_data': kwargs}, exc_info=True)
    
    def critical(self, message: str, **kwargs: Any) -> None:
        """Log critical message with structured context"""
        self.logger.critical(message, extra={'structured_data': kwargs}, exc_info=True)