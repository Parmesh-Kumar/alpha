
import duckdb
import pandas as pd

class ExperimentTracker:
    def __init__(self, db_path: str = "quantos.duckdb"):
        self.conn = duckdb.connect(db_path)

    def initialize(self):
        self.conn.execute(
            '''
            CREATE TABLE IF NOT EXISTS experiments (
                id INTEGER,
                alpha_name VARCHAR,
                sharpe DOUBLE,
                drawdown DOUBLE
            )
            '''
        )

    def log_experiment(
        self,
        alpha_name: str,
        sharpe: float,
        drawdown: float
    ):
        self.conn.execute(
            '''
            INSERT INTO experiments VALUES (?, ?, ?, ?)
            ''',
            (
                1,
                alpha_name,
                sharpe,
                drawdown
            )
        )

    def fetch_all(self) -> pd.DataFrame:
        return self.conn.execute(
            "SELECT * FROM experiments"
        ).fetchdf()
