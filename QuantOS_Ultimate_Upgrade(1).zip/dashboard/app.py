
import streamlit as st
import pandas as pd
import plotly.express as px

st.set_page_config(layout="wide")

st.title("QuantOS Institutional Dashboard")

uploaded = st.file_uploader("Upload Equity Curve CSV")

if uploaded:
    df = pd.read_csv(uploaded)

    st.subheader("Equity Curve")

    fig = px.line(df, y=df.columns[0])

    st.plotly_chart(fig, use_container_width=True)

    returns = df[df.columns[0]].pct_change().fillna(0)

    sharpe = (
        returns.mean() /
        (returns.std() + 1e-9)
    ) * (252 ** 0.5)

    st.metric("Sharpe Ratio", round(float(sharpe), 4))
