"""
QuantOS Market Microstructure Flow Features

Implements flow-based microstructure features including:
- Order flow imbalance
- Trade flow imbalance
- Aggressor identification
- Volume imbalance
"""
from typing import Optional, Dict, List, Tuple
import numpy as np
import pandas as pd

from QuantOS.utils.logger import StructuredLogger
from QuantOS.config.settings import Config

from ..schema import MicrostructureSchema


class FlowFeatures:
    """
    Computes flow-based microstructure features from order/tick data
    
    Features:
    - Order flow imbalance (OFI)
    - Trade flow imbalance (TFI)
    - Aggressor identification
    - Volume imbalance
    - Price pressure
    """
    def __init__(self, window: int = 20):
        self.logger = StructuredLogger(self.__class__.__name__)
        self.window = window
        self.schema = MicrostructureSchema()
    
    def compute_order_flow_imbalance(self, 
                                  df: pd.DataFrame, 
                                  levels: int = 5) -> pd.DataFrame:
        """
        Calculate order flow imbalance (OFI)
        
        Computes the net buying/selling pressure at multiple levels
        
        Args:
            df: DataFrame with order book updates
            levels: Number of price levels to consider
            
        Returns:
            DataFrame with OFI metrics
        """
        try:
            results = []
            
            for i in range(1, levels + 1):
                bid_size_col = f'bid_size_{i}'
                ask_size_col = f'ask_size_{i}'
                
                if bid_size_col not in df.columns or ask_size_col not in df.columns:
                    continue
                    
                # Calculate tiered OFI
                df[f'ofi_{i}'] = df[bid_size_col] - df[ask_size_col]
                df[f'ofi_{i}_ema'] = df[f'ofi_{i}'].ewm(span=self.window).mean()
                
                results.extend([f'ofi_{i}', f'ofi_{i}_ema'])
            
            return df[['timestamp', 'symbol'] + results]
        except Exception as e:
            self.logger.error("Failed to compute order flow imbalance", 
                            error=str(e), 
                            levels=levels)
            raise
    
    def compute_trade_flow_imbalance(self, 
                                   df: pd.DataFrame) -> pd.DataFrame:
        """
        Calculate trade flow imbalance (TFI)
        
        Computes directionality of trades using tick rule
        
        Args:
            df: DataFrame with trade data
            
        Returns:
            DataFrame with TFI signatures
        """
        try:
            # Classify trade direction using tick rule
            df['price_diff'] = df['price'].diff()
            df['trade_sign'] = np.where(
                # Price increase => buyer-initiated
                df['price_diff'] > 0, 1,
                np.where(
                    # Price decrease => seller-initiated
                    df['price_diff'] < 0, -1,
                    # No change => signed volume
                    np.where(
                        df['volume'] > df['volume'].shift(1), 1,
                        np.where(
                            df['volume'] < df['volume'].shift(1), -1,
                            0
                        )
                    )
                )
            )
            
            # Calculate TFI metrics
            df['tfi'] = df['trade_sign'] * df['volume']
            df['tfi_ema'] = df['tfi'].ewm(span=self.window).mean()
            
            df['signed_volume'] = df['trade_sign'] * df['volume']
            df['tfi_net'] = df['signed_volume'].rolling(self.window).sum()
            
            return df[['timestamp', 'symbol', 
                      'tfi', 'tfi_ema', 'tfi_net', 'trade_sign']]
        except Exception as e:
            self.logger.error("Failed to compute trade flow imbalance", 
                            error=str(e))
            raise
    
    def identify_aggressors(self, 
                          trades: pd.DataFrame, 
                          quotes: pd.DataFrame) -> pd.DataFrame:
        """
        Identify aggressor side of trades using quote rule
        
        Args:
            trades: DataFrame with trade data
            quotes: DataFrame with quote data
            
        Returns:
            DataFrame with aggressor markers (-1=ask, 1=bid, 0=unknown)
        """
        try:
            # Merge trades with preceding quotes
            merged = pd.merge_asof(
                trades.sort_values('timestamp'),
                quotes.sort_values('timestamp'),
                on='timestamp',
                direction='backward',
                suffixes=('_trade', '_quote')
            )
            
            # Classify aggressors
            merged['aggressor'] = 0
            
            # Trade above mid => buyer aggressor
            mid = (merged['bid_price'] + merged['ask_price']) / 2
            merged.loc[merged['price'] > mid, 'aggressor'] = 1
            
            # Trade below mid => seller aggressor
            merged.loc[merged['price'] < mid, 'aggressor'] = -1
            
            # Trade at mid => use prevailing imbalance
            at_mid = merged['price'] == mid
            merged.loc[at_mid, 'aggressor'] = np.where(
                (merged['bid_size'] > merged['ask_size']), 1,
                np.where(
                    (merged['ask_size'] > merged['bid_size']), -1,
                    0
                )
            )
            
            return merged[[
                'timestamp_trade', 'symbol_trade', 'price', 
                'volume', 'aggressor'
            ]].rename(columns={
                'timestamp_trade': 'timestamp',
                'symbol_trade': 'symbol'
            })
        except Exception as e:
            self.logger.error("Failed to identify aggressors", 
                            error=str(e))
            raise
    
    def compute_volume_imbalance(self, 
                               df: pd.DataFrame, 
                               levels: int = 5) -> pd.DataFrame:
        """
        Calculate volume imbalance metrics
        
        Args:
            df: DataFrame with order book updates
            levels: Number of price levels to consider
            
        Returns:
            DataFrame with volume imbalance metrics
        """
        try:
            results = []
            
            for i in range(1, levels + 1):
                bid_size_col = f'bid_size_{i}'
                ask_size_col = f'ask_size_{i}'
                
                if bid_size_col not in df.columns or ask_size_col not in df.columns:
                    continue
                    
                # Calculate tiered volume imbalance
                df[f'vol_imb_{i}'] = (
                    (df[bid_size_col] - df[ask_size_col]) /
                    (df[bid_size_col] + df[ask_size_col])
                )
                df[f'vol_imb_{i}_ema'] = df[f'vol_imb_{i}'].ewm(span=self.window).mean()
                
                results.extend([f'vol_imb_{i}', f'vol_imb_{i}_ema'])
            
            return df[['timestamp', 'symbol'] + results]
        except Exception as e:
            self.logger.error("Failed to compute volume imbalance", 
                            error=str(e), 
                            levels=levels)
            raise