"""
QuantOS Market Microstructure Pressure Features

Implements pressure-based microstructure features including:
- Order book pressure
- Trade pressure
- Price elasticity
- Depth imbalance
"""
from typing import Optional, Dict, List, Tuple
import numpy as np
import pandas as pd

from QuantOS.utils.logger import StructuredLogger
from QuantOS.config.settings import Config

from ..schema import MicrostructureSchema


class PressureFeatures:
    """
    Computes pressure-based microstructure features from order/tick data
    
    Features:
    - Price pressure
    - Depth imbalance
    - Order book slope
    - Trade pressure
    - Liquidity absorption
    """
    def __init__(self, window: int = 20):
        self.logger = StructuredLogger(self.__class__.__name__)
        self.window = window
        self.schema = MicrostructureSchema()
    
    def compute_price_pressure(self, 
                             df: pd.DataFrame, 
                             levels: int = 5) -> pd.DataFrame:
        """
        Calculate price pressure across order book levels
        
        Args:
            df: DataFrame with order book updates
            levels: Number of price levels to consider
            
        Returns:
            DataFrame with price pressure metrics
        """
        try:
            results = []
            
            for i in range(1, levels + 1):
                bid_col = f'bid_price_{i}'
                ask_col = f'ask_price_{i}'
                
                if bid_col not in df.columns or ask_col not in df.columns:
                    continue
                    
                # Calculate distance from midpoint
                midpoint = (df['bid_price_1'] + df['ask_price_1']) / 2
                df[f'bid_dist_{i}'] = midpoint - df[bid_col]
                df[f'ask_dist_{i}'] = df[ask_col] - midpoint
                
                # Calculate weighted distances
                bid_size_col = f'bid_size_{i}'
                ask_size_col = f'ask_size_{i}'
                
                if bid_size_col in df.columns and ask_size_col in df.columns:
                    df[f'pressure_bid_{i}'] = df[f'bid_dist_{i}'] * df[bid_size_col]
                    df[f'pressure_ask_{i}'] = df[f'ask_dist_{i}'] * df[ask_size_col]
                    df[f'pressure_net_{i}'] = df[f'pressure_bid_{i}'] - df[f'pressure_ask_{i}']
                    
                    # EMA smoothing
                    df[f'pressure_net_{i}_ema'] = df[f'pressure_net_{i}'].ewm(span=self.window).mean()
                    
                    results.append(f'pressure_net_{i}_ema')
            
            return df[['timestamp', 'symbol'] + results]
        except Exception as e:
            self.logger.error("Failed to compute price pressure", 
                            error=str(e), 
                            levels=levels)
            raise
    
    def compute_depth_imbalance(self, 
                              df: pd.DataFrame, 
                              levels: int = 5) -> pd.DataFrame:
        """
        Calculate depth imbalance ratios
        
        Args:
            df: DataFrame with order book updates
            levels: Number of price levels to consider
            
        Returns:
            DataFrame with depth imbalance metrics
        """
        try:
            results = []
            
            for i in range(1, levels + 1):
                bid_size_col = f'bid_size_{i}'
                ask_size_col = f'ask_size_{i}'
                
                if bid_size_col not in df.columns or ask_size_col not in df.columns:
                    continue
                    
                # Calculate tiered depth imbalances
                df[f'depth_imb_{i}'] = (
                    (df[bid_size_col] - df[ask_size_col]) /
                    (df[bid_size_col] + df[ask_size_col])
                )
                df[f'depth_imb_{i}_ema'] = df[f'depth_imb_{i}'].ewm(span=self.window).mean()
                
                results.extend([f'depth_imb_{i}', f'depth_imb_{i}_ema'])
            
            return df[['timestamp', 'symbol'] + results]
        except Exception as e:
            self.logger.error("Failed to compute depth imbalance", 
                            error=str(e), 
                            levels=levels)
            raise
    
    def compute_book_slopes(self, 
                          df: pd.DataFrame, 
                          levels: int = 5) -> pd.DataFrame:
        """
        Calculate order book slopes (liquidity gradients)
        
        Args:
            df: DataFrame with order book updates
            levels: Number of price levels to consider
            
        Returns:
            DataFrame with slope metrics
        """
        try:
            # Check we have enough levels
            if not all(
                f'bid_price_{i}' in df.columns and f'ask_price_{i}' in df.columns 
                for i in range(1, levels + 1)
            ):
                raise ValueError(f"Need price columns for {levels} levels")
                
            # Calculate bid slope (regression of price vs cumulative volume)
            bid_sizes = [df[f'bid_size_{i}'] for i in range(1, levels + 1)]
            bid_prices = [df[f'bid_price_{i}'] for i in range(1, levels + 1)]
            df['bid_book_slope'] = self._calculate_slopes(bid_prices, bid_sizes)
            
            # Calculate ask slope 
            ask_sizes = [df[f'ask_size_{i}'] for i in range(1, levels + 1)]
            ask_prices = [df[f'ask_price_{i}'] for i in range(1, levels + 1)]
            df['ask_book_slope'] = self._calculate_slopes(ask_prices, ask_sizes)
            
            df['slope_difference'] = df['bid_book_slope'] - df['ask_book_slope']
            
            return df[['timestamp', 'symbol', 
                      'bid_book_slope', 'ask_book_slope', 'slope_difference']]
        except Exception as e:
            self.logger.error("Failed to compute book slopes", 
                            error=str(e), 
                            levels=levels)
            raise
    
    def _calculate_slopes(self, 
                        prices: List[pd.Series], 
                        sizes: List[pd.Series]) -> pd.Series:
        """
        Helper method to calculate regression slopes
        
        Args:
            prices: List of price series for each level
            sizes: List of size series for each level
            
        Returns:
            Series of slope coefficients
        """
        slopes = pd.Series(np.nan, index=prices[0].index)
        
        for i in range(len(prices[0])):
            x = np.array([price.at[i] for price in prices])
            y = np.array([np.log(size.at[i].sum()) for size in sizes])
            
            try:
                slope = np.polyfit(x, y, 1)[0]
                slopes.at[i] = slope
            except:
                continue
                
        return slopes.rolling(self.window).mean()
    
    def compute_trade_pressure(self, 
                             trades: pd.DataFrame, 
                             aggressor_col: str = 'aggressor') -> pd.DataFrame:
        """
        Calculate trade pressure metrics
        
        Args:
            trades: DataFrame with trade data
            aggressor_col: Name of column containing aggressor side
            
        Returns:
            DataFrame with trade pressure metrics
        """
        try:
            if aggressor_col not in trades.columns:
                raise ValueError(f"Missing aggressor column: {aggressor_col}")
                
            # Calculate signed trade metrics
            trades['signed_value'] = trades['price'] * trades['volume'] * trades[aggressor_col]
            
            # Aggregate pressure metrics
            df = trades.set_index('timestamp')
            
            df['pressure_1min'] = (
                df['signed_value']
                .rolling(f'{self.window}T')
                .sum()
            )
            
            df['pressure_ema'] = df['signed_value'].ewm(span=self.window).mean()
            
            return df[['symbol', 'pressure_1min', 'pressure_ema']].reset_index()
        except Exception as e:
            self.logger.error("Failed to compute trade pressure", 
                            error=str(e))
            raise