"""
QuantOS Volatility Estimators

Implements various volatility estimation techniques:
- Parkinson (range-based)
- Garman-Klass
- Rogers-Satchell
- Yang-Zhang
- Complex estimators
- Local volatility surfaces
"""
from typing import Tuple, Dict, List, Optional
import numpy as np
import pandas as pd

from ....utils.logger import StructuredLogger
from ....config.settings import Config


class VolatilityEstimators:
    """
    Implements various volatility estimation techniques
    
    Methods:
    - Parkinson: Range-based volatility estimator
    - Garman-Klass: Extends Parkinson with opening/closing prices
    - Rogers-Satchell: Accounts for drift
    - Yang-Zhang: Combines aspects of other estimators
    """
    def __init__(self, annualization_factor: float = 252):
        self.logger = StructuredLogger(self.__class__.__name__)
        self.ann_factor = annualization_factor
        
    def parkinson(self, 
                highs: np.ndarray, 
                lows: np.ndarray, 
                window: int = 20) -> np.ndarray:
        """
        Parkinson volatility estimator
        
        Uses high-low range to estimate volatility
        
        Args:
            highs: Array of high prices
            lows: Array of low prices
            window: Lookback window
        
        Returns:
            Array of annualized volatility estimates
        """
        try:
            r = np.log(highs / lows)
            variance = (r ** 2).rolling(window=window).mean() / (4 * np.log(2))
            return np.sqrt(variance * self.ann_factor)
        except Exception as e:
            self.logger.error("Parkinson estimator failed", error=str(e))
            raise
    
    def garman_klass(self,
                   highs: np.ndarray,
                   lows: np.ndarray,
                   opens: np.ndarray,
                   closes: np.ndarray,
                   window: int = 20) -> np.ndarray:
        """
        Garman-Klass volatility estimator
        
        Extends Parkinson with opening/closing prices
        
        Args:
            highs: Array of high prices
            lows: Array of low prices
            opens: Array of open prices
            closes: Array of close prices
            window: Lookback window
        
        Returns:
            Array of annualized volatility estimates
        """
        try:
            c = np.log(closes / opens)
            r = np.log(highs / lows)
            
            term1 = 0.5 * (r ** 2)
            term2 = (2 * np.log(2) - 1) * (c ** 2)
            
            variance = (term1 - term2).rolling(window=window).mean()
            return np.sqrt(variance * self.ann_factor)
        except Exception as e:
            self.logger.error("Garman-Klass estimator failed", error=str(e))
            raise
    
    def rogers_satchell(self,
                      highs: np.ndarray,
                      lows: np.ndarray,
                      opens: np.ndarray,
                      closes: np.ndarray,
                      window: int = 20) -> np.ndarray:
        """
        Rogers-Satchell volatility estimator
        
        Accounts for drift in price series
        
        Args:
            highs: Array of high prices
            lows: Array of low prices
            opens: Array of open prices
            closes: Array of close prices
            window: Lookback window
        
        Returns:
            Array of annualized volatility estimates
        """
        try:
            h = np.log(highs / opens)
            l = np.log(lows / opens)
            c = np.log(closes / opens)
            
            term = h * (h - c) + l * (l - c)
            variance = term.rolling(window=window).mean()
            return np.sqrt(variance * self.ann_factor)
        except Exception as e:
            self.logger.error("Rogers-Satchell estimator failed", error=str(e))
            raise
    
    def yang_zhang(self,
                 highs: np.ndarray,
                 lows: np.ndarray,
                 opens: np.ndarray,
                 closes: np.ndarray,
                 window: int = 20,
                 theta: float = 0.34) -> np.ndarray:
        """
        Yang-Zhang volatility estimator
        
        Combines aspects of close-to-close and open-to-open estimators
        
        Args:
            highs: Array of high prices
            lows: Array of low prices
            opens: Array of open prices
            closes: Array of close prices
            window: Lookback window
            theta: Weight parameter (default=0.34)
        
        Returns:
            Array of annualized volatility estimates
        """
        try:
            # Overnight volatility (open-to-close)
            c_o = np.log(closes / opens)
            sigma_o = c_o.rolling(window=window).std(ddof=1)
            
            # Intraday volatility (open-to-high/low/close)
            parkinson = self.parkinson(highs, lows, window)
            rs = self.rogers_satchell(highs, lows, opens, closes, window)
            
            # Combined estimate
            return np.sqrt(
                sigma_o ** 2 + 
                theta * rs ** 2 +
                (1 - theta) * parkinson ** 2
            )
        except Exception as e:
            self.logger.error("Yang-Zhang estimator failed", error=str(e))
            raise
    
    def realized_volatility(self,
                          returns: np.ndarray,
                          window: int = 20,
                          lookback: Optional[int] = None) -> np.ndarray:
        """
        Realized volatility estimator
        
        Args:
            returns: Array of returns
            window: Lookback window
            lookback: Optional period for annualization
        
        Returns:
            Array of annualized volatility estimates
        """
        try:
            if lookback is None:
                lookback = window
                
            var = returns.rolling(window=window).var(ddof=1)
            return np.sqrt(var * (self.ann_factor / lookback))
        except Exception as e:
            self.logger.error("Realized volatility estimator failed", error=str(e))
            raise
    
    def local_volatility_surface(self,
                               prices: pd.DataFrame,
                               moneyness_levels: List[float] = [0.8, 0.9, 1.0, 1.1, 1.2],
                               maturity_levels: List[int] = [1, 5, 10, 20]) -> Dict[str, pd.DataFrame]:
        """
        Estimate local volatility surface
        
        Args:
            prices: DataFrame with OHLC data
            moneyness_levels: List of moneyness levels (S/K)
            maturity_levels: List of maturities (days)
        
        Returns:
            Dictionary of volatility surfaces for each estimator
        """
        try:
            results = {}
            estimators = {
                'parkinson': self.parkinson,
                'garman_klass': self.garman_klass,
                'rogers_satchell': self.rogers_satchell,
                'yang_zhang': self.yang_zhang
            }
            
            for name, func in estimators.items():
                surface = pd.DataFrame(index=maturity_levels, columns=moneyness_levels)
                
                for m in moneyness_levels:
                    for t in maturity_levels:
                        try:
                            # Apply estimator at each moneyness/maturity point
                            vol = func(
                                highs=prices['high'] * m,
                                lows=prices['low'] * m,
                                opens=prices['open'],
                                closes=prices['close'],
                                window=t
                            )[-1]  # Take most recent value
                            
                            surface.at[t, m] = vol
                        except Exception as e:
                            self.logger.warning(
                                f"Failed to estimate {name} volatility at m={m}, t={t}",
                                error=str(e)
                            )
                            continue
                
                results[name] = surface
            
            return results
        except Exception as e:
            self.logger.error("Failed to estimate volatility surface", error=str(e))
