"""
QuantOS Fractal Metrics

Implements fractal analysis techniques for market data:
- Hurst exponent
- Multifractal analysis
- Detrended fluctuation analysis
- Wavelet transforms
"""
from typing import Tuple, Dict, List, Optional
import numpy as np
import pandas as pd
import pywt
from scipy import stats

from QuantOS.utils.logger import StructuredLogger
from QuantOS.config.settings import Config


class FractalAnalysis:
    """
    Implements fractal analysis techniques for financial time series
    
    Methods:
    - hurst_exponent: Estimates persistence/anti-persistence
    - dea: Detrended fluctuation analysis
    - multifractal_spectrum: Computes multifractal properties
    - wavelet_analysis: Multiscale decomposition
    """
    def __init__(self, max_lags: int = 100, q_range: Tuple[float, float] = (-5, 5)):
        self.logger = StructuredLogger(self.__class__.__name__)
        self.max_lags = max_lags
        self.q_range = q_range
    
    def hurst_exponent(self, prices: pd.Series, method: str = 'rs') -> float:
        """
        Estimate Hurst exponent using various methods
        
        Args:
            prices: Price series
            method: Estimation method ('rs'=RS, 'agg'=aggregated variance,
                   'abs'=absolute moments, 'var'=variance)
        
        Returns:
            Hurst exponent estimate (H)
            
        Interpretation:
            - H ~ 0.5: Random walk
            - H > 0.5: Persistent series (trend reinforcing)
            - H < 0.5: Anti-persistent (mean-reverting)
        """
        try:
            lags = range(10, self.max_lags)
            tau = []
            
            if method == 'rs':  # Rescaled range analysis
                for lag in lags:
                    rs_values = []
                    for i in range(0, len(prices) - lag, lag):
                        sub = prices[i:i+lag]
                        mean = np.mean(sub)
                        cum_dev = np.cumsum(sub - mean)
                        rs = (np.max(cum_dev) - np.min(cum_dev)) / np.std(sub)
                        rs_values.append(rs)
                    tau.append(np.log(np.mean(rs_values)))
                
            elif method == 'agg':  # Aggregated variance
                for lag in lags:
                    aggregated = []
                    for i in range(0, len(prices) - lag, lag):
                        chunk = prices[i:i+lag]
                        aggregated.append(np.mean(chunk))
                    tau.append(np.log(np.var(aggregated)))
                
            elif method == 'abs':  # Absolute moments
                q = 1  # Focus on first moment
                for lag in lags:
                    moments = []
                    for i in range(0, len(prices) - lag, lag):
                        chunk = prices[i:i+lag].diff().dropna()
                        moments.append(np.mean(np.abs(chunk)**q))
                    tau.append(np.log(np.mean(moments)))
                
            elif method == 'var':  # Variance of differences
                for lag in lags:
                    diffs = prices.diff(lag).dropna()
                    tau.append(np.log(np.var(diffs)))
            
            else:
                raise ValueError(f"Unknown method: {method}")
            
            # Fit to power law
            poly = np.polyfit(np.log(lags), tau, 1)
            
            # Adjust slope based on method
            if method == 'rs':
                return poly[0]
            elif method == 'agg':
                return 1 + poly[0]/2
            elif method == 'abs':
                return poly[0]/q
            elif method == 'var':
                return poly[0]/2
            
        except Exception as e:
            self.logger.error(f"Failed to compute Hurst exponent (method={method})", 
                           error=str(e))
            raise
    
    def dfa(self, 
           series: pd.Series, 
           scale_range: Tuple[int, int] = (10, 1000),
           num_scales: int = 20) -> Tuple[np.ndarray, np.ndarray, float]:
        """
        Perform Detrended Fluctuation Analysis (DFA)
        
        Args:
            series: Input time series
            scale_range: Tuple of (min_scale, max_scale)
            num_scales: Number of logarithmically spaced scales
        
        Returns:
            (scales, fluctuations, alpha)
            Where alpha is the DFA exponent:
            - alpha ~ 0.5: Uncorrelated/no memory
            - alpha > 0.5: Long-range correlations
            - alpha < 0.5: Anti-correlated
        """
        try:
            # Create logarithmic scales
            scales = np.unique(np.logspace(
                np.log10(scale_range[0]), 
                np.log10(scale_range[1]), 
                num=num_scales
            ).astype(int))
            
            # Integrated series
            y = np.cumsum(series - np.mean(series))
            
            fluctuations = []
            for s in scales:
                # Split into segments
                segments = len(y) // s
                
                # Calculate RMS fluctuation for each segment
                rms = []
                for v in np.split(y[:segments*s], segments):
                    # Fit polynomial (degree 1 = linear detrending)
                    t = np.arange(len(v))
                    coeff = np.polyfit(t, v, 1)
                    trend = np.polyval(coeff, t)
                    
                    # Store RMS of residuals
                    rms.append(np.sqrt(np.mean((v - trend)**2)))
                
                fluctuations.append(np.mean(rms))
            
            # Fit alpha to the log-log relationship
            alpha, _ = np.polyfit(np.log2(scales), np.log2(fluctuations), 1)
            
            return np.array(scales), np.array(fluctuations), alpha
        except Exception as e:
            self.logger.error("DFA failed", error=str(e))
            raise
    
    def multifractal_spectrum(self, 
                            series: pd.Series, 
                            q_values: Optional[np.ndarray] = None,
                            scale_range: Tuple[int, int] = (10, 1000)) -> Dict[str, np.ndarray]:
        """
        Compute multifractal spectrum using MF-DFA
        
        Args:
            series: Input time series
            q_values: Array of q moments to compute (default: linear range)
            scale_range: Tuple of (min_scale, max_scale)
        
        Returns:
            Dictionary with:
            - 'hq': array of generalized Hurst exponents
            - 'tau': array of mass exponents
            - 'falpha': array of singularity strengths
            - 'spectrum': array of fractal dimensions
        """
        try:
            if q_values is None:
                q_values = np.linspace(*self.q_range, 21)
            
            # Get scales and fluctuations
            scales, fluctuations, _ = self.dfa(series, scale_range)
            
            # Calculate q-th order fluctuations
            hq = []
            for q in q_values:
                if q == 0:  # Special case for q=0
                    fq = np.exp(0.5 * np.mean(np.log(fluctuations**2)))
                else:
                    fq = np.power(fluctuations, q).mean() ** (1/q)
                
                # Fit power law
                poly = np.polyfit(np.log2(scales), np.log2(fq), 1)
                hq.append(poly[0])
            
            hq = np.array(hq)
            
            # Compute multifractal spectrum
            tau = q_values * hq - 1
            alpha = np.diff(tau) / np.diff(q_values)
            alpha = np.append(alpha, alpha[-1])  # Extend last value
            
            f_alpha = q_values * alpha - tau
            
            return {
                'hq': hq,
                'tau': tau,
                'falpha': f_alpha,
                'spectrum': alpha
            }
        except Exception as e:
            self.logger.error("Multifractal analysis failed", error=str(e))
            raise
    
    def wavelet_transform(self, 
                        series: pd.Series, 
                        wavelet: str = 'db4', 
                        levels: int = 5) -> Dict[str, np.ndarray]:
        """
        Perform wavelet decomposition (discrete wavelet transform)
        
        Args:
            series: Input time series
            wavelet: Wavelet family (e.g. 'db4')
            levels: Number of decomposition levels
        
        Returns:
            Dictionary with:
            - 'coeffs': Wavelet coefficients
            - 'scales': Equivalent scales
            - 'energies': Energy distribution
            - 'variance': Variance by scale
        """
        try:
            # Decompose series
            coeffs = pywt.wavedec(series, wavelet, level=levels)
            
            # Calculate equivalent scales
            dt = 1  # Assuming unit time steps
            scales = [2**(level+1) * dt for level in reversed(range(levels+1))]
            
            # Energy distribution
            energies = [np.sum(np.square(c)) for c in coeffs]
            total_energy = np.sum(energies)
            energies = [e/total_energy for e in energies]
            
            # Variance by scale
            variance = [np.var(c) for c in coeffs]
            
            return {
                'coeffs': coeffs,
                'scales': scales,
                'energies': energies,
                'variance': variance
            }
        except Exception as e:
            self.logger.error("Wavelet transform failed", error=str(e))
            raise