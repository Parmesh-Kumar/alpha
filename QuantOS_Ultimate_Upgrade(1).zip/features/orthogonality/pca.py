"""
QuantOS Orthogonality Features

Implements Principal Component Analysis (PCA) for feature orthogonality:
- PCA decomposition
- Orthogonal feature extraction
- Variance explained analysis
"""
from typing import Tuple, Dict, List, Optional
import numpy as np
import pandas as pd
from sklearn.decomposition import PCA

from QuantOS.utils.logger import StructuredLogger
from QuantOS.config.settings import Config


class OrthogonalFeatures:
    """
    Implements PCA-based orthogonal feature extraction
    
    Features:
    - PCA decomposition
    - Orthogonal feature extraction
    - Variance explained analysis
    - Feature importance ranking
    """
    def __init__(self, n_components: Optional[int] = None):
        self.logger = StructuredLogger(self.__class__.__name__)
        self.n_components = n_components
        self.pca = PCA(n_components=n_components)
    
    def fit_transform(self, 
                    features: pd.DataFrame,
                    n_components: Optional[int] = None) -> np.ndarray:
        """
        Fit PCA and transform features
        
        Args:
            features: DataFrame with feature data
            n_components: Number of components (default: self.n_components)
        
        Returns:
            Transformed features
        """
        try:
            n_components = n_components or self.n_components
            self.pca = PCA(n_components=n_components)
            
            # Standardize features
            standardized = (features - features.mean()) / features.std()
            
            # Fit and transform
            transformed = self.pca.fit_transform(standardized)
            
            self.logger.info(
                "Successfully fitted PCA",
                n_components=n_components,
                explained_variance=self.pca.explained_variance_ratio_.sum()
            )
            
            return transformed
        except Exception as e:
            self.logger.error("PCA fitting failed", error=str(e))
            raise
    
    def transform(self, 
                 features: pd.DataFrame) -> np.ndarray:
        """
        Transform features using fitted PCA
        
        Args:
            features: DataFrame with feature data
        
        Returns:
            Transformed features
        """
        try:
            # Standardize using original means/stds
            standardized = (features - features.mean()) / features.std()
            return self.pca.transform(standardized)
        except Exception as e:
            self.logger.error("PCA transformation failed", error=str(e))
            raise
    
    def get_components(self) -> np.ndarray:
        """
        Get principal components
        
        Returns:
            Array of principal components
        """
        try:
            return self.pca.components_
        except Exception as e:
            self.logger.error("Failed to get components", error=str(e))
            raise
    
    def get_explained_variance(self) -> np.ndarray:
        """
        Get explained variance ratios
        
        Returns:
            Array of explained variance ratios
        """
        try:
            return self.pca.explained_variance_ratio_
        except Exception as e:
            self.logger.error("Failed to get explained variance", error=str(e))
            raise
    
    def get_feature_importance(self) -> Dict[str, float]:
        """
        Get feature importance scores
        
        Returns:
            Dictionary of feature importance scores
        """
        try:
            # Calculate absolute loadings
            loadings = np.abs(self.pca.components_)
            
            # Sum across components
            importance = np.sum(loadings, axis=0)
            
            return {
                f'feature_{i}': score 
                for i, score in enumerate(importance)
            }
        except Exception as e:
            self.logger.error("Failed to get feature importance", error=str(e))
            raise
    
    def rolling_pca(self, 
                   features: pd.DataFrame,
                   window: int = 100,
                   n_components: Optional[int] = None) -> pd.DataFrame:
        """
        Compute rolling PCA features
        
        Args:
            features: DataFrame with feature data
            window: Rolling window size
            n_components: Number of components (default: self.n_components)
        
        Returns:
            DataFrame with rolling PCA features
        """
        try:
            n_components = n_components or self.n_components
            results = []
            
            for i in range(window, len(features)):
                window_data = features.iloc[i-window:i]
                
                # Fit PCA on window
                pca = PCA(n_components=n_components)
                transformed = pca.fit_transform(window_data)
                
                # Store latest transformed features
                results.append({
                    'timestamp': features.index[i],
                    **{f'pca_{j}': val for j, val in enumerate(transformed[-1])}
                })
            
            return pd.DataFrame(results)
        except Exception as e:
            self.logger.error("Rolling PCA failed", error=str(e))
            raise
    
    def feature_correlation(self, 
                          features: pd.DataFrame,
                          threshold: float = 0.9) -> Dict[str, List[str]]:
        """
        Identify correlated feature groups
        
        Args:
            features: DataFrame with feature data
            threshold: Correlation threshold
        
        Returns:
            Dictionary of correlated feature groups
        """
        try:
            # Compute correlation matrix
            corr = features.corr().abs()
            
            # Find highly correlated features
            groups = {}
            used = set()
            
            for i, col in enumerate(corr.columns):
                if col not in used:
                    # Find correlated features
                    correlated = corr.index[corr[col] > threshold].tolist()
                    
                    if len(correlated) > 1:
                        groups[col] = correlated
                        used.update(correlated)
            
            return groups
        except Exception as e:
            self.logger.error("Feature correlation analysis failed", error=str(e))
            raise