"""
QuantOS Regime Detection

Implements Hidden Markov Models for market regime detection:
- Gaussian HMM
- Trend/reversion/panic/breakout regimes
- Regime transition analysis
"""
from typing import Tuple, Dict, List, Optional
import numpy as np
import pandas as pd
from hmmlearn import hmm

from QuantOS.utils.logger import StructuredLogger
from QuantOS.config.settings import Config


class RegimeDetector:
    """
    Implements Hidden Markov Models for market regime detection
    
    Features:
    - Gaussian HMM with configurable states
    - Regime classification
    - Transition probabilities
    - Regime persistence metrics
    """
    def __init__(self, n_states: int = 4):
        self.logger = StructuredLogger(self.__class__.__name__)
        self.n_states = n_states
        self.model = hmm.GaussianHMM(
            n_components=n_states,
            covariance_type="full",
            n_iter=1000
        )
    
    def fit_model(self, 
                features: pd.DataFrame,
                n_states: Optional[int] = None) -> None:
        """
        Fit HMM model to feature data
        
        Args:
            features: DataFrame with feature data
            n_states: Number of states (default: self.n_states)
        """
        try:
            n_states = n_states or self.n_states
            
            # Convert to numpy array
            X = features.values.reshape(-1, 1) if features.ndim == 1 else features.values
            
            # Fit model
            self.model = hmm.GaussianHMM(
                n_components=n_states,
                covariance_type="full",
                n_iter=1000
            ).fit(X)
            
            self.logger.info(
                "Successfully fitted HMM model",
                n_states=n_states,
                n_features=X.shape[1]
            )
        except Exception as e:
            self.logger.error("HMM fitting failed", error=str(e))
            raise
    
    def predict_regimes(self, 
                      features: pd.DataFrame) -> np.ndarray:
        """
        Predict regimes for given features
        
        Args:
            features: DataFrame with feature data
            
        Returns:
            Array of predicted regime labels
        """
        try:
            X = features.values.reshape(-1, 1) if features.ndim == 1 else features.values
            return self.model.predict(X)
        except Exception as e:
            self.logger.error("Regime prediction failed", error=str(e))
            raise
    
    def get_transition_matrix(self) -> np.ndarray:
        """
        Get state transition probability matrix
        
        Returns:
            Transition matrix (n_states x n_states)
        """
        try:
            return self.model.transmat_
        except Exception as e:
            self.logger.error("Failed to get transition matrix", error=str(e))
            raise
    
    def get_state_means(self) -> np.ndarray:
        """
        Get state means
        
        Returns:
            Array of state means
        """
        try:
            return self.model.means_
        except Exception as e:
            self.logger.error("Failed to get state means", error=str(e))
            raise
    
    def get_state_covariances(self) -> np.ndarray:
        """
        Get state covariances
        
        Returns:
            Array of state covariances
        """
        try:
            return self.model.covars_
        except Exception as e:
            self.logger.error("Failed to get state covariances", error=str(e))
            raise
    
    def classify_regimes(self, 
                       features: pd.DataFrame,
                       regime_names: Optional[List[str]] = None) -> pd.DataFrame:
        """
        Classify regimes with human-readable labels
        
        Args:
            features: DataFrame with feature data
            regime_names: List of regime names (default: ['trend', 'reversion', 'panic', 'breakout'])
            
        Returns:
            DataFrame with regime classifications
        """
        try:
            if regime_names is None:
                regime_names = ['trend', 'reversion', 'panic', 'breakout']
                
            if len(regime_names) != self.n_states:
                raise ValueError(
                    f"Number of regime names ({len(regime_names)}) "
                    f"must match number of states ({self.n_states})"
                )
                
            # Predict raw states
            states = self.predict_regimes(features)
            
            # Sort states by mean return (assuming first feature is returns)
            means = self.get_state_means()
            sorted_indices = np.argsort(means[:, 0])
            
            # Create mapping from state index to regime name
            state_to_regime = {
                i: regime_names[sorted_indices[i]] 
                for i in range(self.n_states)
            }
            
            # Apply classification
            regimes = pd.Series(states).map(state_to_regime)
            
            return pd.DataFrame({
                'timestamp': features.index,
                'regime': regimes,
                'state': states
            })
        except Exception as e:
            self.logger.error("Regime classification failed", error=str(e))
            raise
    
    def regime_persistence(self, 
                         regime_series: pd.Series) -> Dict[str, float]:
        """
        Calculate regime persistence metrics
        
        Args:
            regime_series: Series of regime labels
            
        Returns:
            Dictionary with persistence metrics
        """
        try:
            # Calculate regime durations
            changes = regime_series.ne(regime_series.shift())
            durations = changes.groupby((changes).cumsum()).cumcount() + 1
            
            # Calculate metrics
            return {
                'mean_duration': durations.mean(),
                'median_duration': durations.median(),
                'max_duration': durations.max(),
                'min_duration': durations.min(),
                'transition_count': len(changes[changes == True])
            }
        except Exception as e:
            self.logger.error("Regime persistence calculation failed", error=str(e))
            raise
    
    def rolling_regime_probabilities(self, 
                                   features: pd.DataFrame,
                                   window: int = 100) -> pd.DataFrame:
        """
        Compute rolling regime probabilities
        
        Args:
            features: DataFrame with feature data
            window: Rolling window size
            
        Returns:
            DataFrame with regime probabilities
        """
        try:
            results = []
            
            for i in range(window, len(features)):
                window_data = features.iloc[i-window:i]
                X = window_data.values.reshape(-1, 1) if window_data.ndim == 1 else window_data.values
                
                # Get posterior probabilities
                probs = self.model.predict_proba(X)[-1]  # Latest probabilities
                
                results.append({
                    'timestamp': features.index[i],
                    **{f'prob_state_{j}': p for j, p in enumerate(probs)}
                })
            
            return pd.DataFrame(results)
        except Exception as e:
            self.logger.error("Rolling regime probability calculation failed", error=str(e))
            raise