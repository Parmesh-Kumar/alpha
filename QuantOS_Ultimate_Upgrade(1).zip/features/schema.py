"""
QuantOS Feature Schemas

Defines standard schemas for different feature types to ensure consistency.
"""
import pyarrow as pa
from typing import Dict, Any
from dataclasses import dataclass


@dataclass
class MicrostructureSchema:
    """
    Schema definitions for microstructure features
    """
    def __init__(self):
        # Common microstructure schema
        self.quote_schema = pa.schema([
            ('timestamp', pa.timestamp('ns', 'UTC')),
            ('symbol', pa.string()),
            ('bid_price', pa.float64()),
            ('ask_price', pa.float64()),
            ('bid_size', pa.float64()),
            ('ask_size', pa.float64())
        ])
        
        self.multilevel_quote_schema = pa.schema([
            ('timestamp', pa.timestamp('ns', 'UTC')),
            ('symbol', pa.string()),
        ] + [
            (f'{side}_price_{level}', pa.float64())
            for level in range(1, 6)
            for side in ['bid', 'ask']
        ] + [
            (f'{side}_size_{level}', pa.float64())
            for level in range(1, 6)
            for side in ['bid', 'ask']
        ])
        
        self.trade_schema = pa.schema([
            ('timestamp', pa.timestamp('ns', 'UTC')),
            ('symbol', pa.string()),
            ('price', pa.float64()),
            ('volume', pa.float64()),
            ('direction', pa.int8())
        ])
        
        self.feature_schema = pa.schema([
            ('timestamp', pa.timestamp('ns', 'UTC')),
            ('symbol', pa.string()),
            ('feature_name', pa.string()),
            ('feature_value', pa.float64())
        ])