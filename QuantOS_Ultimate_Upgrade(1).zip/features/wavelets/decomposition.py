"""
QuantOS Wavelet Decomposition

Implements wavelet-based feature extraction for financial time series:
- Discrete wavelet transform
- Continuous wavelet transform
- Wavelet packet decomposition
- Denoising
"""
from typing import Tuple, Dict, List, Optional
import numpy as np
import pandas as pd
import pywt

from QuantOS.utils.logger import StructuredLogger
from QuantOS.config.settings import Config


class WaveletDecomposition:
    """
    Implements wavelet-based feature extraction for financial time series
    
    Methods:
    - dwt: Discrete wavelet transform
    - cwt: Continuous wavelet transform
    - wavelet_packet: Wavelet packet decomposition
    - denoise: Wavelet-based denoising
    """
    def __init__(self, wavelet: str = 'db4', levels: int = 5):
        self.logger = StructuredLogger(self.__class__.__name__)
        self.wavelet = wavelet
        self.levels = levels
    
    def dwt(self, 
           series: pd.Series, 
           wavelet: Optional[str] = None,
           levels: Optional[int] = None) -> Dict[str, np.ndarray]:
        """
        Perform discrete wavelet transform
        
        Args:
            series: Input time series
            wavelet: Wavelet family (default: self.wavelet)
            levels: Number of decomposition levels (default: self.levels)
        
        Returns:
            Dictionary with:
            - 'approximation': Low-frequency component
            - 'details': List of detail coefficients
            - 'reconstruction': Reconstructed signal
        """
        try:
            wavelet = wavelet or self.wavelet
            levels = levels or self.levels
            
            # Decompose
            coeffs = pywt.wavedec(series, wavelet, level=levels)
            
            # Extract approximation and details
            approximation = coeffs[0]
            details = coeffs[1:]
            
            # Reconstruct
            reconstruction = pywt.waverec(coeffs, wavelet)
            
            return {
                'approximation': approximation,
                'details': details,
                'reconstruction': reconstruction[:len(series)]  # Trim to original length
            }
        except Exception as e:
            self.logger.error("DWT failed", error=str(e))
            raise
    
    def cwt(self, 
           series: pd.Series, 
           scales: Optional[np.ndarray] = None,
           wavelet: Optional[str] = None) -> Dict[str, np.ndarray]:
        """
        Perform continuous wavelet transform
        
        Args:
            series: Input time series
            scales: Array of scales (default: logarithmic range)
            wavelet: Wavelet family (default: self.wavelet)
        
        Returns:
            Dictionary with:
            - 'coefficients': CWT coefficients matrix
            - 'scales': Scales used
            - 'frequencies': Equivalent frequencies
        """
        try:
            wavelet = wavelet or self.wavelet
            
            if scales is None:
                scales = np.logspace(0, np.log10(len(series)/2), 50)
            
            # Compute CWT
            coefficients, frequencies = pywt.cwt(
                series, scales, wavelet, sampling_period=1
            )
            
            return {
                'coefficients': coefficients,
                'scales': scales,
                'frequencies': frequencies
            }
        except Exception as e:
            self.logger.error("CWT failed", error=str(e))
            raise
    
    def wavelet_packet(self, 
                      series: pd.Series, 
                      wavelet: Optional[str] = None,
                      levels: Optional[int] = None) -> Dict[str, np.ndarray]:
        """
        Perform wavelet packet decomposition
        
        Args:
            series: Input time series
            wavelet: Wavelet family (default: self.wavelet)
            levels: Number of decomposition levels (default: self.levels)
        
        Returns:
            Dictionary with:
            - 'nodes': Dictionary of wavelet packet nodes
            - 'energies': Energy distribution across nodes
            - 'entropy': Entropy of each node
        """
        try:
            wavelet = wavelet or self.wavelet
            levels = levels or self.levels
            
            # Create wavelet packet
            wp = pywt.WaveletPacket(
                series, wavelet, mode='symmetric', maxlevel=levels
            )
            
            # Extract nodes
            nodes = {}
            energies = {}
            entropy = {}
            
            for node in wp.get_level(levels, 'natural'):
                node_path = node.path
                node_data = node.data
                
                nodes[node_path] = node_data
                energies[node_path] = np.sum(np.square(node_data))
                entropy[node_path] = -np.sum(
                    np.square(node_data) * np.log(np.square(node_data) + 1e-10)
                )
            
            return {
                'nodes': nodes,
                'energies': energies,
                'entropy': entropy
            }
        except Exception as e:
            self.logger.error("Wavelet packet decomposition failed", error=str(e))
            raise
    
    def denoise(self, 
               series: pd.Series, 
               threshold: Optional[float] = None,
               wavelet: Optional[str] = None,
               levels: Optional[int] = None) -> pd.Series:
        """
        Denoise time series using wavelet thresholding
        
        Args:
            series: Input time series
            threshold: Threshold value (default: universal threshold)
            wavelet: Wavelet family (default: self.wavelet)
            levels: Number of decomposition levels (default: self.levels)
        
        Returns:
            Denoised time series
        """
        try:
            wavelet = wavelet or self.wavelet
            levels = levels or self.levels
            
            # Decompose
            coeffs = pywt.wavedec(series, wavelet, level=levels)
            
            # Calculate universal threshold if not provided
            if threshold is None:
                sigma = np.median(np.abs(coeffs[-1])) / 0.6745
                threshold = sigma * np.sqrt(2 * np.log(len(series)))
            
            # Apply soft thresholding to detail coefficients
            denoised_coeffs = [coeffs[0]]  # Keep approximation
            for detail in coeffs[1:]:
                denoised_coeffs.append(
                    pywt.threshold(detail, threshold, mode='soft')
                )
            
            # Reconstruct
            denoised = pywt.waverec(denoised_coeffs, wavelet)
            
            return pd.Series(denoised[:len(series)], index=series.index)
        except Exception as e:
            self.logger.error("Denoising failed", error=str(e))
            raise
    
    def extract_features(self, 
                        series: pd.Series, 
                        wavelet: Optional[str] = None,
                        levels: Optional[int] = None) -> pd.DataFrame:
        """
        Extract wavelet-based features from time series
        
        Args:
            series: Input time series
            wavelet: Wavelet family (default: self.wavelet)
            levels: Number of decomposition levels (default: self.levels)
        
        Returns:
            DataFrame with wavelet features
        """
        try:
            wavelet = wavelet or self.wavelet
            levels = levels or self.levels
            
            # Perform DWT
            dwt_result = self.dwt(series, wavelet, levels)
            
            features = {}
            
            # Energy features
            total_energy = np.sum(np.square(dwt_result['approximation']))
            for i, detail in enumerate(dwt_result['details']):
                total_energy += np.sum(np.square(detail))
            
            features['approx_energy_ratio'] = (
                np.sum(np.square(dwt_result['approximation'])) / total_energy
            )
            
            for i, detail in enumerate(dwt_result['details']):
                features[f'detail_{i+1}_energy_ratio'] = (
                    np.sum(np.square(detail)) / total_energy
                )
            
            # Statistical features
            features['approx_mean'] = np.mean(dwt_result['approximation'])
            features['approx_std'] = np.std(dwt_result['approximation'])
            features['approx_skew'] = pd.Series(dwt_result['approximation']).skew()
            features['approx_kurtosis'] = pd.Series(dwt_result['approximation']).kurtosis()
            
            for i, detail in enumerate(dwt_result['details']):
                features[f'detail_{i+1}_std'] = np.std(detail)
                features[f'detail_{i+1}_skew'] = pd.Series(detail).skew()
                features[f'detail_{i+1}_kurtosis'] = pd.Series(detail).kurtosis()
            
            return pd.DataFrame([features])
        except Exception as e:
            self.logger.error("Feature extraction failed", error=str(e))
            raise