"""
QuantOS Rough Path Signatures

Implements rough path signature features for financial time series:
- Path signatures
- Signature moments
- Signature-based features
"""
from typing import Tuple, Dict, List, Optional
import numpy as np
import pandas as pd

from QuantOS.utils.logger import StructuredLogger
from QuantOS.config.settings import Config


class RoughPathSignatures:
    """
    Implements rough path signature features for financial time series
    
    Methods:
    - compute_signature: Compute path signature
    - signature_moments: Compute signature moments
    - signature_features: Extract signature-based features
    """
    def __init__(self, truncation_level: int = 3):
        self.logger = StructuredLogger(self.__class__.__name__)
        self.truncation_level = truncation_level
    
    def compute_signature(self, 
                        path: np.ndarray, 
                        truncation_level: Optional[int] = None) -> np.ndarray:
        """
        Compute path signature up to truncation level
        
        Args:
            path: Array of shape (n_points, n_dimensions)
            truncation_level: Maximum level of signature (default: self.truncation_level)
        
        Returns:
            Array of signature coefficients
        """
        try:
            truncation_level = truncation_level or self.truncation_level
            
            n_points, n_dims = path.shape
            
            # Initialize signature
            signature = []
            
            # Level 0: constant term
            signature.append(1.0)
            
            # Level 1: path increments
            increments = np.diff(path, axis=0)
            for d in range(n_dims):
                signature.append(np.sum(increments[:, d]))
            
            # Level 2: iterated integrals
            for d1 in range(n_dims):
                for d2 in range(n_dims):
                    integral = 0
                    for i in range(n_points - 1):
                        for j in range(i + 1, n_points - 1):
                            integral += increments[i, d1] * increments[j, d2]
                    signature.append(integral)
            
            # Level 3: triple iterated integrals
            if truncation_level >= 3:
                for d1 in range(n_dims):
                    for d2 in range(n_dims):
                        for d3 in range(n_dims):
                            integral = 0
                            for i in range(n_points - 1):
                                for j in range(i + 1, n_points - 1):
                                    for k in range(j + 1, n_points - 1):
                                        integral += (
                                            increments[i, d1] * 
                                            increments[j, d2] * 
                                            increments[k, d3]
                                        )
                            signature.append(integral)
            
            return np.array(signature)
        except Exception as e:
            self.logger.error("Signature computation failed", error=str(e))
            raise
    
    def signature_moments(self, 
                        path: np.ndarray, 
                        truncation_level: Optional[int] = None) -> Dict[str, float]:
        """
        Compute signature moments
        
        Args:
            path: Array of shape (n_points, n_dimensions)
            truncation_level: Maximum level of signature (default: self.truncation_level)
        
        Returns:
            Dictionary with signature moments
        """
        try:
            signature = self.compute_signature(path, truncation_level)
            
            moments = {
                'mean': np.mean(signature),
                'std': np.std(signature),
                'skewness': pd.Series(signature).skew(),
                'kurtosis': pd.Series(signature).kurtosis(),
                'l1_norm': np.sum(np.abs(signature)),
                'l2_norm': np.sqrt(np.sum(np.square(signature))),
                'max_abs': np.max(np.abs(signature)),
                'energy': np.sum(np.square(signature))
            }
            
            return moments
        except Exception as e:
            self.logger.error("Signature moments computation failed", error=str(e))
            raise
    
    def signature_features(self, 
                         prices: pd.DataFrame, 
                         window: int = 20) -> pd.DataFrame:
        """
        Extract signature-based features from price data
        
        Args:
            prices: DataFrame with OHLC data
            window: Rolling window size
        
        Returns:
            DataFrame with signature features
        """
        try:
            features = []
            
            for i in range(window, len(prices)):
                # Extract window
                window_data = prices.iloc[i-window:i]
                
                # Create path from OHLC data
                path = np.column_stack([
                    window_data['open'].to_numpy(),
                    window_data['high'].to_numpy(),
                    window_data['low'].to_numpy(),
                    window_data['close'].to_numpy()
                ])
                
                # Compute signature
                signature = self.compute_signature(path)
                
                # Store features
                feature_dict = {
                    'timestamp': prices.index[i],
                    'symbol': prices['symbol'].iloc[i] if 'symbol' in prices.columns else 'UNKNOWN'
                }
                
                for j, coeff in enumerate(signature):
                    feature_dict[f'sig_{j}'] = coeff
                
                features.append(feature_dict)
            
            return pd.DataFrame(features)
        except Exception as e:
            self.logger.error("Signature feature extraction failed", error=str(e))
            raise
    
    def rolling_signature(self, 
                        path: np.ndarray, 
                        window: int = 20,
                        truncation_level: Optional[int] = None) -> np.ndarray:
        """
        Compute rolling path signatures
        
        Args:
            path: Array of shape (n_points, n_dimensions)
            window: Rolling window size
            truncation_level: Maximum level of signature (default: self.truncation_level)
        
        Returns:
            Array of rolling signature coefficients
        """
        try:
            truncation_level = truncation_level or self.truncation_level
            
            n_points = len(path)
            signatures = []
            
            for i in range(window, n_points):
                window_path = path[i-window:i]
                sig = self.compute_signature(window_path, truncation_level)
                signatures.append(sig)
            
            return np.array(signatures)
        except Exception as e:
            self.logger.error("Rolling signature computation failed", error=str(e))
            raise