"""
QuantOS Entropy Metrics

Implements thermodynamic entropy measures for market microstructure analysis:
- Price entropy
- Volume entropy
- Order flow entropy
- Mutual information
"""
from typing import Tuple, Dict, List, Optional
import numpy as np
import pandas as pd
from scipy.stats import entropy as scipy_entropy

from QuantOS.utils.logger import StructuredLogger
from QuantOS.config.settings import Config


class ThermodynamicEntropy:
    """
    Computes thermodynamic entropy measures from market data
    
    Features:
    - Price direction entropy
    - Volume clustering entropy
    - Order flow imbalance entropy
    - Mutual information between flows and price changes
    """
    def __init__(self, bins: int = 50, window: int = 200):
        self.logger = StructuredLogger(self.__class__.__name__)
        self.bins = bins  # Number of bins for PDF estimation
        self.window = window  # Rolling window for calculations
    
    def price_entropy(self, 
                    prices: pd.Series, 
                    normalized: bool = True) -> pd.Series:
        """
        Compute entropy of price changes
        
        Args:
            prices: Array of price values
            normalized: Whether to normalize between 0-1
        
        Returns:
            Array of entropy values
        """
        try:
            returns = np.diff(np.log(prices))
            
            # Compute rolling entropy
            entropies = returns.rolling(window=self.window).apply(
                lambda x: scipy_entropy(
                    np.histogram(x, bins=self.bins, density=True)[0]
                )
            )
            
            if normalized:
                max_entropy = np.log(self.bins)
                entropies = entropies / max_entropy
                
            return entropies
        except Exception as e:
            self.logger.error("Failed to compute price entropy", error=str(e))
            raise
    
    def volume_entropy(self, 
                     volumes: pd.Series, 
                     normalized: bool = True) -> pd.Series:
        """
        Compute entropy of volume distribution
        
        Args:
            volumes: Array of volume values
            normalized: Whether to normalize between 0-1
        
        Returns:
            Array of entropy values
        """
        try:
            # Compute rolling entropy
            entropies = volumes.rolling(window=self.window).apply(
                lambda x: scipy_entropy(
                    np.histogram(x, bins=self.bins, density=True)[0]
                )
            )
            
            if normalized:
                max_entropy = np.log(self.bins)
                entropies = entropies / max_entropy
                
            return entropies
        except Exception as e:
            self.logger.error("Failed to compute volume entropy", error=str(e))
            raise
    
    def order_flow_entropy(self, 
                         buy_volumes: np.ndarray, 
                         sell_volumes: np.ndarray) -> np.ndarray:
        """
        Compute entropy of order flow imbalance
        
        Args:
            buy_volumes: Array of buy volumes
            sell_volumes: Array of sell volumes
        
        Returns:
            Array of entropy values (0-1 normalized)
        """
        try:
            ratios = buy_volumes / (buy_volumes + sell_volumes + 1e-10)
            
            # Compute entropy using binary entropy formula
            entropies = -(ratios * np.log(ratios + 1e-10) + 
                         (1 - ratios) * np.log(1 - ratios + 1e-10))
            
            # Normalize (max entropy is ln(2))
            return entropies / np.log(2)
        except Exception as e:
            self.logger.error("Failed to compute order flow entropy", error=str(e))
            raise
    
    def mutual_information(self,
                         flows: np.ndarray,
                         returns: np.ndarray,
                         bins: int = 10) -> float:
        """
        Compute mutual information between flows and returns
        
        Measures how much uncertainty about returns is reduced by knowing flows
        
        Args:
            flows: Array of order flow values
            returns: Array of returns
            bins: Number of bins for joint PDF estimation
        
        Returns:
            Mutual information score
        """
        try:
            # Create 2D histogram for joint distribution
            joint_prob, _, _ = np.histogram2d(
                flows, returns, bins=bins, density=True
            )
            
            # Compute marginal distributions
            p_flows = np.sum(joint_prob, axis=1)
            p_returns = np.sum(joint_prob, axis=0)
            
            # Calculate mutual information
            mi = 0
            for i in range(bins):
                for j in range(bins):
                    if joint_prob[i,j] > 0:
                        mi += joint_prob[i,j] * np.log(
                            joint_prob[i,j] / (p_flows[i] * p_returns[j] + 1e-10)
                        )
            
            return mi
        except Exception as e:
            self.logger.error("Failed to compute mutual information", error=str(e))
            raise
    
    def rolling_mutual_info(self,
                          flows: np.ndarray,
                          returns: np.ndarray,
                          bins: int = 10) -> np.ndarray:
        """
        Rolling window mutual information
        
        Args:
            flows: Array of order flows
            returns: Array of returns
            bins: Number of bins for PDF calculation
        
        Returns:
            Array of rolling mutual information scores
        """
        try:
            results = np.zeros(len(flows))
            results[:] = np.nan
            
            for i in range(self.window, len(flows)):
                window_flows = flows[i-self.window:i]
                window_returns = returns[i-self.window:i]
                results[i] = self.mutual_information(window_flows, window_returns, bins)
                
            return results
        except Exception as e:
            self.logger.error("Failed to compute rolling mutual information", error=str(e))
            raise
    
    def hurst_exponent(self,
                      prices: np.ndarray,
                      max_lags: int = 100) -> float:
        """
        Estimate Hurst exponent using rescaled range analysis
        
        Args:
            prices: Price series
            max_lags: Maximum lags for R/S calculation
        
        Returns:
            Hurst exponent estimate
        """
        try:
            lags = range(10, max_lags)
            tau = [np.std(np.diff(np.log(prices), lag)) for lag in lags]
            
            # Fit to power law
            poly = np.polyfit(np.log(lags), np.log(tau), 1)
            return poly[0]
        except Exception as e:
            self.logger.error("Failed to compute Hurst exponent", error=str(e))
            raise