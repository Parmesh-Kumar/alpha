"""
QuantOS Feature Engineering Pipeline

Implements the complete feature generation pipeline that orchestrates:
- Feature generation
- Feature selection
- Feature storage
- Feature monitoring
"""
from typing import Dict, List, Optional, Tuple
import numpy as np
import pandas as pd
from pathlib import Path

from QuantOS.utils.logger import StructuredLogger
from QuantOS.config.settings import Config
from QuantOS.data.cache_engine import FeatureCache

from .microstructure.flow import FlowFeatures
from .microstructure.pressure import PressureFeatures
from .volatility.estimators import VolatilityEstimators
from .entropy.thermodynamics import ThermodynamicEntropy
from .fractals.chaos import FractalAnalysis
from .wavelets.decomposition import WaveletDecomposition
from .topology.geometry import TopologyFeatures
from .signatures.roughpath import RoughPathSignatures
from .regimes.hmm import RegimeDetector
from .orthogonality.pca import OrthogonalFeatures


class FeaturePipeline:
    """
    Orchestrates the complete feature engineering pipeline
    
    Features:
    - Automated feature generation
    - Feature selection
    - Feature caching
    - Feature monitoring
    """
    def __init__(self):
        self.logger = StructuredLogger(self.__class__.__name__)
        self.cache = FeatureCache()
        
        # Initialize feature generators
        self.flow_features = FlowFeatures()
        self.pressure_features = PressureFeatures()
        self.volatility_estimators = VolatilityEstimators()
        self.entropy_metrics = ThermodynamicEntropy()
        self.fractal_metrics = FractalAnalysis()
        self.wavelet_features = WaveletDecomposition()
        self.topology_features = TopologyFeatures()
        self.signature_features = RoughPathSignatures()
        self.regime_detector = RegimeDetector()
        self.orthogonal_features = OrthogonalFeatures()
    
    def generate_features(self, 
                         data: pd.DataFrame,
                         feature_types: Optional[List[str]] = None) -> Dict[str, pd.DataFrame]:
        """
        Generate all features for given data
        
        Args:
            data: Input OHLCV data
            feature_types: List of feature types to generate (default: all)
            
        Returns:
            Dictionary of feature DataFrames keyed by feature type
        """
        try:
            results = {}
            
            # Default to all feature types if not specified
            if feature_types is None:
                feature_types = [
                    'microstructure',
                    'volatility',
                    'entropy',
                    'fractal',
                    'wavelet',
                    'topology',
                    'signatures',
                    'regimes',
                    'orthogonality'
                ]
            
            # Generate microstructure features
            if 'microstructure' in feature_types:
                results['flow'] = self.flow_features.compute_order_flow_imbalance(data)
                results['pressure'] = self.pressure_features.compute_price_pressure(data)
            
            # Generate volatility features
            if 'volatility' in feature_types:
                results['volatility'] = pd.DataFrame({
                    'parkinson': self.volatility_estimators.parkinson(
                        data['high'].to_numpy(), data['low'].to_numpy()
                    ),
                    'garman_klass': self.volatility_estimators.garman_klass(
                        data['high'].to_numpy(), 
                        data['low'].to_numpy(), 
                        data['open'].to_numpy(), 
                        data['close'].to_numpy()
                    ),
                    'yang_zhang': self.volatility_estimators.yang_zhang(
                        data['high'].to_numpy(), 
                        data['low'].to_numpy(), 
                        data['open'].to_numpy(), 
                        data['close'].to_numpy()
                    )
                })
            
            # Generate entropy features
            if 'entropy' in feature_types:
                results['entropy'] = pd.DataFrame({
                    'price_entropy': self.entropy_metrics.price_entropy(data['close']),
                    'volume_entropy': self.entropy_metrics.volume_entropy(data['volume'])
                })
            
            # Generate fractal features
            if 'fractal' in feature_types:
                hurst = self.fractal_metrics.hurst_exponent(data['close'])
                dfa_scales, dfa_fluct, dfa_alpha = self.fractal_metrics.dfa(data['close'])
                results['fractal'] = pd.DataFrame({
                    'hurst': [hurst] * len(data),
                    'dfa_alpha': [dfa_alpha] * len(data)
                })
            
            # Generate wavelet features
            if 'wavelet' in feature_types:
                wavelet_result = self.wavelet_features.extract_features(data['close'])
                results['wavelet'] = wavelet_result
            
            # Generate topology features
            if 'topology' in feature_types:
                traj_result = self.topology_features.trajectory_analysis(data['close'])
                results['topology'] = pd.DataFrame(traj_result, index=data.index)
            
            # Generate signature features
            if 'signatures' in feature_types:
                path = np.column_stack([data['open'], data['high'], data['low'], data['close']])
                sig_moments = self.signature_features.signature_moments(path)
                results['signatures'] = pd.DataFrame(sig_moments, index=data.index)
            
            # Generate regime features
            if 'regimes' in feature_types:
                returns = data['close'].pct_change().dropna()
                self.regime_detector.fit_model(returns.to_frame())
                results['regimes'] = self.regime_detector.classify_regimes(returns.to_frame())
            
            # Generate orthogonal features
            if 'orthogonality' in feature_types:
                features = pd.concat([
                    results['flow'],
                    results['pressure'],
                    results['volatility'],
                    results['entropy'],
                    results['fractal'],
                    results['wavelet'],
                    results['topology'],
                    results['signatures']
                ], axis=1)
                
                # Remove any existing NaN values
                features = features.dropna()
                
                # Compute orthogonal features
                orthogonal = self.orthogonal_features.fit_transform(features)
                results['orthogonal'] = pd.DataFrame(
                    orthogonal,
                    index=features.index,
                    columns=[f'ortho_{i}' for i in range(orthogonal.shape[1])]
                )
            
            # Cache all generated features
            for feature_type, df in results.items():
                self.cache.store_features(
                    feature_name=feature_type,
                    symbol=data['symbol'].iloc[0] if 'symbol' in data.columns else 'UNKNOWN',
                    df=df,
                    generation_params={'feature_types': feature_types}
                )
            
            return results
        except Exception as e:
            self.logger.error("Feature generation failed", error=str(e))
            raise
    
    def select_features(self, 
                      features: Dict[str, pd.DataFrame],
                      importance_threshold: float = 0.01) -> List[str]:
        """
        Select most important features based on variance explained
        
        Args:
            features: Dictionary of feature DataFrames
            importance_threshold: Minimum importance score
            
        Returns:
            List of selected feature names
        """
        try:
            # Combine all features
            combined = pd.concat(features.values(), axis=1)
            
            # Compute feature importance
            self.orthogonal_features.fit_transform(combined)
            importance = self.orthogonal_features.get_feature_importance()
            
            # Select features above threshold
            selected = [
                f for f, score in importance.items() 
                if score >= importance_threshold
            ]
            
            self.logger.info(
                "Feature selection completed",
                n_selected=len(selected),
                threshold=importance_threshold
            )
            
            return selected
        except Exception as e:
            self.logger.error("Feature selection failed", error=str(e))
            raise
    
    def monitor_feature_quality(self, 
                              features: Dict[str, pd.DataFrame]) -> Dict[str, Dict[str, float]]:
        """
        Compute quality metrics for generated features
        
        Args:
            features: Dictionary of feature DataFrames
            
        Returns:
            Dictionary of quality metrics per feature type
        """
        try:
            quality = {}
            
            for name, df in features.items():
                quality[name] = {
                    'mean': df.mean().mean(),
                    'std': df.std().mean(),
                    'null_pct': df.isnull().mean().mean(),
                    'stability': df.rolling(20).std().mean().mean()
                }
            
            return quality
        except Exception as e:
            self.logger.error("Feature quality monitoring failed", error=str(e))
            raise
    
    def run_pipeline(self, 
                    data: pd.DataFrame,
                    feature_types: Optional[List[str]] = None) -> Dict[str, pd.DataFrame]:
        """
        Run complete feature engineering pipeline
        
        Args:
            data: Input OHLCV data
            feature_types: List of feature types to generate (default: all)
            
        Returns:
            Dictionary of selected feature DataFrames
        """
        try:
            # Generate features
            features = self.generate_features(data, feature_types)
            
            # Select important features
            selected = self.select_features(features)
            
            # Monitor feature quality
            quality = self.monitor_feature_quality(features)
            self.logger.info("Feature quality metrics", metrics=quality)
            
            # Return only selected features
            return {
                k: v for k, v in features.items()
                if k in selected
            }
        except Exception as e:
            self.logger.error("Feature pipeline failed", error=str(e))
            raise