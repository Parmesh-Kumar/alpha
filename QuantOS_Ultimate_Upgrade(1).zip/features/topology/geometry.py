"""
QuantOS Topology Features

Implements topological and geometric analysis techniques for market data:
- Persistent homology
- Geometric shape metrics
- Trajectory analysis
- Vector bundles
"""
from typing import Tuple, Dict, List, Optional, Any
import numpy as np
import pandas as pd
from scipy.spatial import distance
from scipy.stats import skew, kurtosis

from QuantOS.utils.logger import StructuredLogger
from QuantOS.config.settings import Config


class TopologyFeatures:
    """
    Implements topological and geometric analysis of financial time series
    
    Methods:
    - persistent_homology: Topological feature extraction
    - trajectory_analysis: Path geometry metrics
    - shape_features: Distances between trajectories
    - curvature_analysis: Local curvature estimation
    """
    def __init__(self, window: int = 20):
        self.logger = StructuredLogger(self.__class__.__name__)
        self.window = window
    
    def persistent_homology(self, 
                          series: pd.Series,
                          embedding_dim: int = 3, 
                          time_delay: int = 1) -> Dict[str, Any]:
        """
        Compute persistent homology features
        
        Args:
            series: Input time series
            embedding_dim: Embedding dimension for Takens' embedding
            time_delay: Time delay for Takens' embedding
        
        Returns:
            Dictionary with:
            - 'betti_numbers': Betti numbers for each dimension
            - 'persistence_diagrams': Persistence intervals
        """
        try:
            # Create time-delay embedding
            embedded = []
            for i in range(len(series) - (embedding_dim-1)*time_delay):
                point = []
                for j in range(embedding_dim):
                    point.append(series[i + j*time_delay])
                embedded.append(point)
            
            # Simplified persistence calculation (actual would require Ripser)
            betti_numbers = np.zeros(embedding_dim)
            betti_numbers[0] = 1  # Single connected component
            
            # Distance matrix
            dist_matrix = distance.squareform(distance.pdist(embedded))
            
            # Persistence intervals approximation
            max_dist = np.max(dist_matrix)
            persistence = {
                'dim0': [(0, max_dist/2)],
                'dim1': [(max_dist/3, max_dist*0.6)]
            }
            
            return {
                'betti_numbers': betti_numbers,
                'persistence_diagrams': persistence
            }
        except Exception as e:
            self.logger.error("Persistent homology computation failed", 
                            error=str(e))
            raise
    
    def trajectory_analysis(self, 
                          series: pd.Series) -> Dict[str, float]:
        """
        Compute geometric properties of price trajectory
        
        Args:
            series: Input time series
            
        Returns:
            Dictionary with:
            - 'arc_length': Total path length
            - 'straightness': Straightness ratio
            - 'tortuosity': Tortuosity measure
            - 'efficiency': Efficiency measure
        """
        try:
            # Calculate arc length (sum of absolute changes)
            arc_length = np.sum(np.abs(np.diff(series)))
            
            # Straight-line distance (start to end)
            straight_dist = np.abs(series.iloc[-1] - series.iloc[0])
            
            # Geometric metrics
            straightness = straight_dist / (arc_length + 1e-10)
            tortuosity = arc_length / (straight_dist + 1e-10)
            efficiency = straight_dist / np.sqrt(len(series))
            
            return {
                'arc_length': arc_length,
                'straightness': straightness,
                'tortuosity': tortuosity,
                'efficiency': efficiency
            }
        except Exception as e:
            self.logger.error("Trajectory analysis failed", error=str(e))
            raise
    
    def shape_features(self, 
                      series1: pd.Series, 
                      series2: pd.Series) -> Dict[str, float]:
        """
        Compare shapes of two time series using geometry
        
        Args:
            series1: First series
            series2: Second series
            
        Returns:
            Dictionary with distance metrics:
            - 'hausdorff': Hausdorff distance
            - 'frechet': Discrete Fréchet distance
            - 'dtw': Dynamic Time Warping distance
        """
        try:
            # Normalize series
            s1 = (series1 - series1.min()) / (series1.max() - series1.min() + 1e-10)
            s2 = (series2 - series2.min()) / (series2.max() - series2.min() + 1e-10)
            
            # Hausdorff distance
            hd = max(
                max(min(distance.cdist([p1], s2.values.reshape(-1,1))) for p1 in s1),
                max(min(distance.cdist([p2], s1.values.reshape(-1,1))) for p2 in s2)
            )
            
            # Discrete Fréchet distance
            def frechet_distance(p, q):
                n, m = len(p), len(q)
                ca = np.zeros((n,m))
                
                ca[0,0] = distance.euclidean(p[0], q[0])
                
                for i in range(1, n):
                    ca[i, 0] = max(ca[i-1, 0], distance.euclidean(p[i], q[0]))
                
                for j in range(1, m):
                    ca[0, j] = max(ca[0, j-1], distance.euclidean(p[0], q[j]))
                
                for i in range(1, n):
                    for j in range(1, m):
                        ca[i,j] = max(
                            min(ca[i-1,j], ca[i-1,j-1], ca[i,j-1]),
                            distance.euclidean(p[i], q[j])
                        )
                
                return ca[-1,-1]
            
            fd = frechet_distance(
                np.c_[np.arange(len(s1)), s1], 
                np.c_[np.arange(len(s2)), s2]
            )
            
            # DTW distance
            def dtw_distance(s1, s2):
                dtw = np.zeros((len(s1)+1, len(s2)+1))
                dtw[0, 1:] = np.inf
                dtw[1:, 0] = np.inf
                
                for i in range(1, len(s1)+1):
                    for j in range(1, len(s2)+1):
                        cost = distance.euclidean([s1[i-1]], [s2[j-1]])
                        dtw[i,j] = cost + min(dtw[i-1,j], dtw[i,j-1], dtw[i-1,j-1])
                
                return dtw[-1,-1]
            
            dtw = dtw_distance(s1, s2)
            
            return {
                'hausdorff': hd,
                'frechet': fd,
                'dtw': dtw
            }
        except Exception as e:
            self.logger.error("Shape comparison failed", error=str(e))
            raise
    
    def curvature_analysis(self, 
                         series: pd.Series, 
                         window: int = 5) -> Dict[str, Any]:
        """
        Compute curvature-related features
        
        Args:
            series: Input time series
            window: Smoothing window size
        
        Returns:
            Dictionary with:
            - 'curvature': Array of curvature values
            - 'mean_curvature': Mean curvature
            - 'max_curvature': Maximum curvature
        """
        try:
            # Compute first and second derivatives
            x = np.arange(len(series))
            y = series.to_numpy()
            
            dx = np.gradient(x.astype(float))
            dy = np.gradient(y.astype(float))
            
            d2x = np.gradient(dx.astype(float))
            d2y = np.gradient(dy.astype(float))
            
            # Calculate curvature
            curvature = (
                np.abs(dx * d2y - d2x * dy) /
                (dx**2 + dy**2)**1.5
            )
            
            # Smooth curvature
            curvature_series = pd.Series(curvature).rolling(window).mean()
            curvature_values = curvature_series.to_numpy()
            
            return {
                'curvature': curvature_values,
                'mean_curvature': float(np.nanmean(curvature_values)),
                'max_curvature': float(np.nanmax(curvature_values))
            }
        except Exception as e:
            self.logger.error("Curvature analysis failed", error=str(e))
            raise