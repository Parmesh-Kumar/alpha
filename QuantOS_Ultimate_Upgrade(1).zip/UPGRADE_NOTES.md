
# QuantOS Upgrade Notes

Added:
- DEAP GP evolution engine
- DuckDB experiment tracking
- Streamlit dashboard
- Worker pool orchestration
- Atomic checkpointing
- Live inference engine

Next suggested upgrades:
- regime-aware GP swarms
- alpha governance decay logic
- Bayesian confidence throttling
- market impact curves
- feature registry
- alpha lineage graphs
- distributed orchestration
