
import pickle
from pathlib import Path

class StateSaver:
    def __init__(self, checkpoint_dir: str = "checkpoints"):
        self.checkpoint_dir = Path(checkpoint_dir)
        self.checkpoint_dir.mkdir(exist_ok=True)

    def save(self, name: str, state):
        path = self.checkpoint_dir / f"{name}.pkl"

        temp = str(path) + ".tmp"

        with open(temp, "wb") as f:
            pickle.dump(state, f)

        Path(temp).replace(path)

    def load(self, name: str):
        path = self.checkpoint_dir / f"{name}.pkl"

        if not path.exists():
            return None

        with open(path, "rb") as f:
            return pickle.load(f)
