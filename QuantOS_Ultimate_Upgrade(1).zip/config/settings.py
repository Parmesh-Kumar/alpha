"""
QuantOS Configuration Settings

This module contains all system-wide configuration settings for the QuantOS platform.
"""
from typing import Dict, Any
import os
from pathlib import Path

# Base Configuration
class Config:
    """Base configuration class with default settings"""
    DEBUG = False
    TESTING = False
    
    # Data directories
    DATA_DIR = Path(os.getenv('QUANTOS_DATA_DIR', 'e:\\Code\\QuantOS\\data'))
    CACHE_DIR = DATA_DIR / 'cache'
    
    # Database settings
    DATABASE_URI = 'duckdb:///{}'.format((DATA_DIR / 'quantos.db').as_posix())
    
    # Logging configuration
    LOGGING_CONFIG: Dict[str, Any] = {
        'version': 1,
        'disable_existing_loggers': False,
        'formatters': {
            'standard': {
                'format': '%(asctime)s [%(levelname)s] %(name)s: %(message)s'
            },
        },
        'handlers': {
            'default': {
                'level': 'INFO',
                'formatter': 'standard',
                'class': 'logging.StreamHandler',
                'stream': 'ext://sys.stdout',
            },
        },
        'loggers': {
            '': {  # root logger
                'handlers': ['default'],
                'level': 'INFO',
                'propagate': False
            },
            'quantos': {
                'handlers': ['default'],
                'level': 'DEBUG',
                'propagate': False
            },
        }
    }
    
    # Feature generation parameters
    FEATURE_PARAMS = {
        'volatility_window': 20,
        'entropy_window': 50,
        'fractal_window': 100
    }
    
    # Backtesting parameters
    BACKTEST_PARAMS = {
        'initial_capital': 1_000_000,
        'commission': 0.0005,  # 0.05%
        'slippage': 0.0002    # 0.02%
    }


class ProductionConfig(Config):
    """Production configuration"""
    pass


class DevelopmentConfig(Config):
    """Development configuration"""
    DEBUG = True


class TestingConfig(Config):
    """Testing configuration"""
    TESTING = True
    DATABASE_URI = 'duckdb:///:memory:'