
from dataclasses import dataclass

@dataclass
class ExecutionResult:
    filled_price: float
    slippage: float
    total_cost: float

class ExecutionSimulator:
    def __init__(self, slippage_bps: float = 5.0):
        self.slippage_bps = slippage_bps

    def simulate(self, price: float, quantity: float) -> ExecutionResult:
        slippage = price * (self.slippage_bps / 10000)
        filled = price + slippage
        cost = filled * quantity
        return ExecutionResult(
            filled_price=filled,
            slippage=slippage,
            total_cost=cost
        )
