
from dataclasses import dataclass

@dataclass
class IndianMarketFrictions:
    stt_rate: float = 0.00025
    gst_rate: float = 0.18
    sebi_rate: float = 0.000001
    stamp_duty_rate: float = 0.00003
    brokerage_rate: float = 0.0003

    def calculate_total_cost(self, turnover: float) -> float:
        brokerage = turnover * self.brokerage_rate
        gst = brokerage * self.gst_rate
        stt = turnover * self.stt_rate
        sebi = turnover * self.sebi_rate
        stamp = turnover * self.stamp_duty_rate

        return brokerage + gst + stt + sebi + stamp
