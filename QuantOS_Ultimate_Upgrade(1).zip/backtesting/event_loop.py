
from dataclasses import dataclass, field
from typing import List

@dataclass
class Position:
    quantity: float = 0.0
    avg_price: float = 0.0

@dataclass
class Portfolio:
    cash: float = 1_000_000
    position: Position = field(default_factory=Position)
    equity_curve: List[float] = field(default_factory=list)

class EventDrivenBacktester:
    def __init__(self):
        self.portfolio = Portfolio()

    def on_bar(self, close_price: float, signal: int):
        if signal == 1 and self.portfolio.cash > close_price:
            qty = int(self.portfolio.cash // close_price)
            self.portfolio.position.quantity += qty
            self.portfolio.position.avg_price = close_price
            self.portfolio.cash -= qty * close_price

        elif signal == -1 and self.portfolio.position.quantity > 0:
            self.portfolio.cash += self.portfolio.position.quantity * close_price
            self.portfolio.position.quantity = 0

        equity = self.portfolio.cash + (
            self.portfolio.position.quantity * close_price
        )

        self.portfolio.equity_curve.append(equity)
