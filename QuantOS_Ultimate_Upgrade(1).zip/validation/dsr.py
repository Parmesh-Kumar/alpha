
import numpy as np

def sharpe_ratio(returns: np.ndarray, risk_free: float = 0.0) -> float:
    excess = returns - risk_free
    std = np.std(excess)
    if std == 0:
        return 0.0
    return np.sqrt(252) * np.mean(excess) / std

def deflated_sharpe_ratio(
    returns: np.ndarray,
    trials: int = 100
) -> float:
    sr = sharpe_ratio(returns)
    penalty = np.sqrt(np.log(max(trials, 2)))
    return sr / penalty
