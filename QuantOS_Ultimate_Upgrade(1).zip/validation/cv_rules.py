
import numpy as np
from typing import Iterator, Tuple

class PurgedKFold:
    def __init__(self, n_splits: int = 5, embargo_pct: float = 0.01):
        self.n_splits = n_splits
        self.embargo_pct = embargo_pct

    def split(self, X: np.ndarray) -> Iterator[Tuple[np.ndarray, np.ndarray]]:
        n_samples = len(X)
        indices = np.arange(n_samples)
        fold_size = n_samples // self.n_splits

        for i in range(self.n_splits):
            test_start = i * fold_size
            test_end = n_samples if i == self.n_splits - 1 else (i + 1) * fold_size

            test_indices = indices[test_start:test_end]

            embargo = int(n_samples * self.embargo_pct)

            train_mask = np.ones(n_samples, dtype=bool)
            train_mask[max(0, test_start - embargo):min(n_samples, test_end + embargo)] = False

            train_indices = indices[train_mask]

            yield train_indices, test_indices
