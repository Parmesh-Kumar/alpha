
from pathlib import Path
import pandas as pd

from validation.cv_rules import PurgedKFold
from validation.dsr import sharpe_ratio
from backtesting.event_loop import EventDrivenBacktester

def generate_signals(df: pd.DataFrame):
    fast = df['close'].rolling(10).mean()
    slow = df['close'].rolling(30).mean()

    signal = (fast > slow).astype(int)
    signal[fast < slow] = -1
    return signal.fillna(0)

def run_pipeline(csv_path: str):
    df = pd.read_csv(csv_path)

    if 'close' not in df.columns:
        raise ValueError("CSV must contain close column")

    signals = generate_signals(df)

    bt = EventDrivenBacktester()

    for close, signal in zip(df['close'], signals):
        bt.on_bar(float(close), int(signal))

    returns = pd.Series(bt.portfolio.equity_curve).pct_change().fillna(0)

    print("Final Equity:", bt.portfolio.equity_curve[-1])
    print("Sharpe:", sharpe_ratio(returns.values))

    cv = PurgedKFold()

    for train_idx, test_idx in cv.split(df.values):
        print("Train:", len(train_idx), "Test:", len(test_idx))

if __name__ == "__main__":
    csv = Path("data.csv")
    if csv.exists():
        run_pipeline(str(csv))
    else:
        print("Place market data CSV as data.csv")
