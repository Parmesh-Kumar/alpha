
import pandas as pd

class LiveInferenceEngine:
    def __init__(self):
        self.history = []

    def update(self, row: dict):
        self.history.append(row)

    def latest_frame(self) -> pd.DataFrame:
        return pd.DataFrame(self.history)

    def infer(self):
        if len(self.history) < 30:
            return 0

        df = self.latest_frame()

        fast = df['close'].rolling(10).mean()
        slow = df['close'].rolling(30).mean()

        if fast.iloc[-1] > slow.iloc[-1]:
            return 1

        return -1
