"""
QuantOS Data Ingestion Module

This module handles the ingestion and processing of financial data into the QuantOS system.
"""
from typing import Dict, Any, Optional
from pathlib import Path
import pyarrow as pa
import pyarrow.parquet as pq
import pandas as pd
import numpy as np

from ..utils.logger import StructuredLogger
from ..config.settings import Config


class DataIngestor:
    """
    Base class for data ingestion operations
    
    Handles:
    - Schema validation
    - Timezone normalization
    - Parquet caching
    - Lazy loading
    """
    def __init__(self):
        self.logger = StructuredLogger(__name__)
        self.schema = self._get_schema()
        
    def _get_schema(self) -> pa.Schema:
        """Define the Arrow schema for OHLCV data"""
        return pa.schema([
            ('timestamp', pa.timestamp('ns')),
            ('open', pa.float64()),
            ('high', pa.float64()),
            ('low', pa.float64()),
            ('close', pa.float64()),
            ('volume', pa.float64()),
            ('symbol', pa.string())
        ])
    
    def ingest_csv(self, filepath: Path, symbol: str) -> Optional[pa.Table]:
        """
        Ingest OHLCV data from CSV file
        
        Args:
            filepath: Path to CSV file
            symbol: Instrument symbol
            
        Returns:
            PyArrow Table with validated data
        """
        try:
            df = pd.read_csv(filepath)
            df['symbol'] = symbol
            table = pa.Table.from_pandas(df, schema=self.schema)
            return self._validate_and_normalize(table)
        except Exception as e:
            self.logger.error(f"Failed to ingest CSV {filepath}", error=str(e))
            return None
    
    def _validate_and_normalize(self, table: pa.Table) -> pa.Table:
        """
        Validate schema and normalize data
        
        Args:
            table: Input data table
            
        Returns:
            Validated and normalized table
        """
        try:
            # Validate schema
            if not table.schema.equals(self.schema):
                self.logger.warning("Schema mismatch - attempting to cast")
                table = table.cast(self.schema)
            
            # Normalize timestamps to UTC
            if pa.types.is_timestamp(table.schema.field('timestamp').type):
                tz = table.schema.field('timestamp').type.tz
                if tz is None or tz != 'UTC':
                    self.logger.debug("Converting timestamps to UTC")
                    timestamps = table.column('timestamp').to_pandas()
                    if tz:
                        timestamps = timestamps.dt.tz_convert('UTC')
                    else:
                        timestamps = timestamps.dt.tz_localize('UTC')
                    table = table.set_column(
                        table.schema.get_field_index('timestamp'),
                        'timestamp',
                        pa.array(timestamps, type=pa.timestamp('ns', 'UTC'))
                    )
            
            return table
        except Exception as e:
            self.logger.error("Validation/normalization failed", error=str(e))
            raise
    
    def cache_to_parquet(self, table: pa.Table, output_path: Path) -> None:
        """
        Cache data to Parquet format
        
        Args:
            table: Data to cache
            output_path: Destination path
        """
        try:
            # Ensure parent directory exists
            output_path.parent.mkdir(parents=True, exist_ok=True)
            
            pq.write_table(table, output_path)
            self.logger.info(
                "Successfully cached data",
                path=output_path.as_posix(),
                rows=table.num_rows
            )
        except Exception as e:
            self.logger.error("Failed to cache data", error=str(e))
            raise
    
    def lazy_load_parquet(self, path: Path) -> pa.Table:
        """
        Lazy load data from Parquet file
        
        Args:
            path: Path to parquet file
            
        Returns:
            PyArrow Table with lazy-loaded data
        """
        return pq.ParquetFile(path)


class OHLCVIngestor(DataIngestor):
    """
    Specialized ingestor for OHLCV data
    
    Adds additional validation specific to OHLCV data
    """
    def _validate_and_normalize(self, table: pa.Table) -> pa.Table:
        """
        OHLCV-specific validation:
        - Ensure high >= low
        - Ensure prices are positive
        """
        table = super()._validate_and_normalize(table)
        
        # Convert to pandas for validation (could be done with pyarrow compute too)
        df = table.to_pandas()
        
        # Validate prices
        price_columns = ['open', 'high', 'low', 'close']
        if (df[price_columns] <= 0).any().any():
            self.logger.warning("Found non-positive prices", count=(df[price_columns] <= 0).sum().sum())
            
        # Validate high >= low
        invalid_rows = df['high'] < df['low']
        if invalid_rows.any():
            self.logger.warning(
                "Found invalid rows where high < low",
                count=invalid_rows.sum(),
                first_occurrence=df.loc[invalid_rows, 'timestamp'].iloc[0]
            )
            
        return table