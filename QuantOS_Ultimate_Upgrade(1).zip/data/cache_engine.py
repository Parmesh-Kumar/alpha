"""
QuantOS Data Caching Engine

Implements a high-performance caching system for quant research data.
"""
import os
from pathlib import Path
from typing import Dict, Any, Optional, Union

import pyarrow as pa
import pyarrow.parquet as pq
import pandas as pd
import numpy as np

from ..utils.logger import StructuredLogger
from ..config.settings import Config


class CacheEngine:
    """
    High-performance caching engine for time series data
    
    Features:
    - Tiered caching (memory/disk)
    - Smart eviction policies
    - Compression
    - Schema validation
    """
    def __init__(self):
        self.logger = StructuredLogger(__name__)
        self.memory_cache: Dict[str, Union[pa.Table, pd.DataFrame]] = {}
        self.cache_dir = Config.CACHE_DIR
        self.cache_dir.mkdir(parents=True, exist_ok=True)
    
    def store_table(self, 
                  key: str, 
                  data: Union[pa.Table, pd.DataFrame], 
                  overwrite: bool = False) -> bool:
        """
        Store data in cache
        
        Args:
            key: Unique cache key
            data: Data to cache (PyArrow Table or Pandas DataFrame)
            overwrite: Whether to overwrite existing cache entry
            
        Returns:
            True if successful
        """
        try:
            # Convert to Arrow table if needed
            if isinstance(data, pd.DataFrame):
                data = pa.Table.from_pandas(data)
                
            # Check if already exists
            if not overwrite and self.has_key(key):
                self.logger.warning("Key already exists", key=key)
                return False
                
            # Store in memory
            self.memory_cache[key] = data
            
            # Persist to disk
            cache_path = self._get_cache_path(key)
            pq.write_table(data, cache_path, compression='ZSTD')
            
            self.logger.debug(
                "Successfully cached table", 
                key=key, 
                rows=data.num_rows,
                size_bytes=data.nbytes
            )
            return True
        except Exception as e:
            self.logger.error("Cache store failed", key=key, error=str(e))
            return False
    
    def get_table(self, key: str, force_disk: bool = False) -> Optional[pa.Table]:
        """
        Retrieve data from cache
        
        Args:
            key: Cache key to retrieve
            force_disk: Skip memory cache and read directly from disk
            
        Returns:
            Cached data table or None if not found
        """
        try:
            # First check memory cache
            if not force_disk and key in self.memory_cache:
                self.logger.debug("Cache hit (memory)", key=key)
                cached = self.memory_cache[key]
                return cached if isinstance(cached, pa.Table) else pa.Table.from_pandas(cached)
                
            # Check disk cache
            cache_path = self._get_cache_path(key)
            if cache_path.exists():
                self.logger.debug("Cache hit (disk)", key=key)
                table = pq.read_table(cache_path)
                # Update memory cache while keeping LRU order
                self.memory_cache[key] = table
                return table
                
            self.logger.debug("Cache miss", key=key)
            return None
        except Exception as e:
            self.logger.error("Cache retrieval failed", key=key, error=str(e))
            return None
    
    def has_key(self, key: str) -> bool:
        """Check if key exists in cache"""
        return key in self.memory_cache or self._get_cache_path(key).exists()
    
    def clear_key(self, key: str) -> bool:
        """Remove item from cache"""
        try:
            memory_removed = self.memory_cache.pop(key, None) is not None
            disk_path = self._get_cache_path(key)
            disk_removed = False
            if disk_path.exists():
                disk_path.unlink()
                disk_removed = True
                
            self.logger.debug(
                "Cleared cache key", 
                key=key, 
                memory_removed=memory_removed,
                disk_removed=disk_removed
            )
            return memory_removed or disk_removed
        except Exception as e:
            self.logger.error("Failed to clear cache key", key=key, error=str(e))
            return False
    
    def clear_all(self) -> None:
        """Clear all cached data"""
        try:
            self.memory_cache.clear()
            for file in self.cache_dir.glob('*.parquet'):
                file.unlink()
            self.logger.info("Cleared all cached data")
        except Exception as e:
            self.logger.error("Failed to clear cache", error=str(e))
            raise
    
    def _get_cache_path(self, key: str) -> Path:
        """Get filesystem path for cache key"""
        safe_key = ''.join(c if c.isalnum() else '_' for c in key)
        return self.cache_dir / f"{safe_key}.parquet"
    

class FeatureCache(CacheEngine):
    """Specialized cache for feature datasets"""
    def __init__(self):
        super().__init__()
        self.version = "1.0"  # Cache version for schema compatibility
        self.feature_schema = self._get_feature_schema()
        
    def _get_feature_schema(self) -> pa.Schema:
        """Define schema for feature datasets"""
        return pa.schema([
            ('timestamp', pa.timestamp('ns', 'UTC')),
            ('symbol', pa.string()),
            ('feature_name', pa.string()),
            ('feature_value', pa.float64()),
            ('generation_params', pa.string())  # JSON-encoded
        ])
    
    def store_features(self, 
                     feature_name: str,
                     symbol: str,
                     df: pd.DataFrame,
                     generation_params: Dict[str, Any],
                     overwrite: bool = False) -> bool:
        """
        Specialized method for storing feature datasets
        
        Args:
            feature_name: Name of the feature
            symbol: Instrument symbol
            df: Feature data
            generation_params: Parameters used to generate features
            overwrite: Whether to overwrite existing cache entry
            
        Returns:
            True if successful
        """
        try:
            # Prepare feature table
            if 'timestamp' not in df.columns:
                raise ValueError("Feature data must contain timestamp column")
                
            feature_df = pd.DataFrame({
                'timestamp': df['timestamp'],
                'symbol': symbol,
                'feature_name': feature_name,
                'feature_value': df['feature_value'] if 'feature_value' in df else df[feature_name],
                'generation_params': str(generation_params)
            })
            
            # Create Arrow table with proper schema
            table = pa.Table.from_pandas(feature_df, schema=self.feature_schema)
            
            cache_key = f"features::{symbol}::{feature_name}"
            return self.store_table(cache_key, table, overwrite=overwrite)
        except Exception as e:
            self.logger.error("Failed to cache features", 
                            feature_name=feature_name,
                            symbol=symbol,
                            error=str(e))
            return False