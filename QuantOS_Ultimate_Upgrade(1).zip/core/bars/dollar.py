"""
QuantOS Dollar Bar Generation

Implements dollar-based bar generation for financial time series.
"""
from typing import Tuple, Optional, List, Dict
import numpy as np
import pandas as pd

from QuantOS.utils.logger import StructuredLogger
from QuantOS.config.settings import Config


class DollarBars:
    """
    Generates dollar bars from tick/transaction data
    
    Features:
    - Exact dollar bar generation
    - Variable dollar thresholds
    - OHLCV aggregation
    - Multivariate dollar measures
    """
    def __init__(self):
        self.logger = StructuredLogger(self.__class__.__name__)
        
    def generate_bars(self, 
                     df: pd.DataFrame,
                     amount_col: str = 'amount',
                     threshold: float = 10000.0,
                     timestamp_col: str = 'timestamp',
                     price_col: str = 'price') -> pd.DataFrame:
        """
        Generate dollar bars from raw data
        
        Args:
            df: Input DataFrame with timestamp, price and dollar amount
            amount_col: Name of dollar amount column (price * volume)
            threshold: Dollar threshold per bar
            timestamp_col: Name of timestamp column
            price_col: Name of price column
            
        Returns:
            DataFrame with OHLCV dollar bars
        """
        try:
            # Validate input
            required_cols = [timestamp_col, price_col, amount_col]
            if not all(col in df.columns for col in required_cols):
                raise ValueError(f"Missing required columns. Need: {required_cols}")
                
            # Sort by timestamp
            df = df.sort_values(timestamp_col)
            
            # Initialize variables
            bars = []
            cumulative_amount = 0
            current_bar = None
            
            for _, tick in df.iterrows():
                tick_price = tick[price_col]
                tick_amount = tick[amount_col]
                
                # Initialize new bar if needed
                if current_bar is None:
                    current_bar = {
                        'timestamp': tick[timestamp_col],
                        'open': tick_price,
                        'high': tick_price,
                        'low': tick_price,
                        'close': tick_price,
                        'amount': 0,
                        'volume': 0
                    }
                
                # Update current bar
                current_bar['high'] = max(current_bar['high'], tick_price)
                current_bar['low'] = min(current_bar['low'], tick_price)
                current_bar['close'] = tick_price
                current_bar['amount'] += tick_amount
                
                # Estimate volume from amount (if volume column not available)
                estimated_volume = tick_amount / tick_price
                current_bar['volume'] += estimated_volume
                
                cumulative_amount += tick_amount
                
                # Check if threshold reached
                if cumulative_amount >= threshold:
                    # Finalize current bar
                    current_bar['timestamp'] = tick[timestamp_col]
                    bars.append(current_bar)
                    
                    # Reset for next bar
                    cumulative_amount = 0
                    current_bar = None
            
            # Handle partial bar at end
            if current_bar is not None:
                bars.append(current_bar)
            
            # Create and return results
            result = pd.DataFrame(bars)
            result['symbol'] = df['symbol'].iloc[0] if 'symbol' in df.columns else 'UNKNOWN'
            return result
            
        except Exception as e:
            self.logger.error("Failed to generate dollar bars", 
                            error=str(e),
                            columns=list(df.columns),
                            threshold=threshold)
            raise

    def generate_multivariate_bars(self,
                                 df: pd.DataFrame,
                                 weighted_cols: List[str],
                                 weights: List[float],
                                 threshold: float = 10000.0) -> pd.DataFrame:
        """
        Generate dollar bars using multiple weighted measures
        
        Args:
            df: Input DataFrame
            weighted_cols: List of weighted measure columns
            weights: Weight for each measure
            threshold: Effective dollar threshold
            
        Returns:
            DataFrame with OHLCV bars
        """
        try:
            if len(weighted_cols) != len(weights):
                raise ValueError("weighted_cols and weights must have same length")
                
            # Calculate effective dollar amount
            df['effective_amount'] = sum(
                df[col] * weight 
                for col, weight in zip(weighted_cols, weights)
            )
            
            # Generate bars using effective amount
            return self.generate_bars(
                df=df,
                amount_col='effective_amount',
                threshold=threshold
            )
        except Exception as e:
            self.logger.error("Failed to generate multivariate dollar bars",
                            error=str(e),
                            weighted_cols=weighted_cols,
                            weights=weights)
            raise